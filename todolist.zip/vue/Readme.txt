Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: https://makitweb.com/insert-update-delete-records-from-mysql-with-vue-js/

Instructions - 

## Import attached users.sql file in your MySQL database.
## Update config.php file.

